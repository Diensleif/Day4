﻿using MedicalLaboratory.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace MedicalLaboratory.Windows
{
    /// <summary>
    /// Логика взаимодействия для AssistantWindow.xaml
    /// </summary>
    public partial class AssistantWindow : Window
    {
        private User _user;
        private Entities _entities = new Entities();

        public AssistantWindow(int userId)
        {
            InitializeComponent();

            _user = _entities.User.First(x => x.Id == userId);

            // Вывод информации о пользователе
            PhotoOutput.Source = new BitmapImage(
                new Uri("/Resources/Images/Лаборант 1.jpeg",
                UriKind.Relative));
            FullNameOutput.Text = $"{_user.Name} {_user.Surname}";
            UserTypeOutput.Text = _user.UserType.Name;

            // Настройка таймера
            _timer.Interval = TimeSpan.FromSeconds(1);
            _timer.Tick += _timer_Tick;

            _sessionTime = TimeSpan.FromMinutes(10);
            Title = _sessionTime.ToString();

            _timer.Start();
        }

        private void _timer_Tick(object sender, EventArgs e)
        {
            _sessionTime = TimeSpan.FromSeconds(_sessionTime.TotalSeconds - 1);
            Title = _sessionTime.ToString();

            // Если осталось 5 минут, вывести предупреждение
            if (_sessionTime.TotalMinutes == 5)
            {
                MessageBox.Show("До окончания сеанса осталось 5 минут",
                    "Внимание",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
            }

            // Если время сеанса закончилось и пользователь не вышел сам,
            // заблокировать его
            if (_sessionTime.TotalSeconds == 0)
            {
                _user.LastSystemLogout = DateTime.Now;
                _entities.SaveChanges();

                var mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }
        }

        private TimeSpan _sessionTime;
        private DispatcherTimer _timer = new DispatcherTimer();

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
