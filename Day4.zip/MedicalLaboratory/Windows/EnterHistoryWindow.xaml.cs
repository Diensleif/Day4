﻿using MedicalLaboratory.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MedicalLaboratory.Windows
{
    /// <summary>
    /// Логика взаимодействия для EnterHistoryWindow.xaml
    /// </summary>
    public partial class EnterHistoryWindow : Window
    {
        private Entities _entities = new Entities();

        public EnterHistoryWindow()
        {
            InitializeComponent();

            RefreshEnterHistory(string.Empty, null, null);
        }

        /// <summary>
        /// Обновление истории входа
        /// </summary>
        /// <param name="search">Фильтрация по логину</param>
        /// <param name="from">Фильтрация по дате: больше указанного значения</param>
        /// <param name="to">Фильтрация по дате: меньше указанного значения</param>
        private void RefreshEnterHistory(string search, DateTime? from, DateTime? to)
        {
            var enterHistory = _entities.User.AsEnumerable();

            // Фильтрация по логину
            if (!string.IsNullOrEmpty(search))
            {
                enterHistory = enterHistory.Where(x => x.Login.Contains(search));
            }

            // Фильтрация по дате: больше указанного значения
            if (from != null)
            {
                enterHistory = enterHistory.Where(x => x.LastEnter >= from);
            }

            // Фильтрация по дате: меньше указанного значения
            if (to != null)
            {
                enterHistory = enterHistory.Where(x => x.LastEnter <= to);
            }

            EnterHistory.ItemsSource = enterHistory.ToList();
        }

        private void SearchInput_TextChanged(object sender, TextChangedEventArgs e)
        {
            RefreshEnterHistory(SearchInput.Text,
                FromDateInput.SelectedDate,
                ToDateInput.SelectedDate);
        }

        private void FromDateInput_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            RefreshEnterHistory(SearchInput.Text,
                FromDateInput.SelectedDate,
                ToDateInput.SelectedDate);
        }

        private void ToDateInput_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            RefreshEnterHistory(SearchInput.Text,
                FromDateInput.SelectedDate,
                ToDateInput.SelectedDate);
        }
    }
}
