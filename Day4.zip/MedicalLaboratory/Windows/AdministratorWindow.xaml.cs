﻿using MedicalLaboratory.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MedicalLaboratory.Windows
{
    /// <summary>
    /// Логика взаимодействия для AdministratorWindow.xaml
    /// </summary>
    public partial class AdministratorWindow : Window
    {
        private User _user;
        private Entities _entities = new Entities();

        public AdministratorWindow(int userId)
        {
            InitializeComponent();

            _user = _entities.User.First(x => x.Id == userId);

            PhotoOutput.Source = new BitmapImage(
                new Uri("/Resources/Images/Администратор.png",
                UriKind.Relative));
            FullNameOutput.Text = $"{_user.Name} {_user.Surname}";
            UserTypeOutput.Text = _user.UserType.Name;
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void EnterHistoryButton_Click(object sender, RoutedEventArgs e)
        {
            var enterHistoryWindow = new EnterHistoryWindow();
            enterHistoryWindow.ShowDialog();
        }
    }
}
