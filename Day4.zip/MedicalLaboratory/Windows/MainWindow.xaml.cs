﻿using MedicalLaboratory.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MedicalLaboratory.Windows
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Entities _entities = new Entities();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void PasswordCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            PasswordInput.Text = MaskedPasswordInput.Password;
            PasswordInput.Visibility = Visibility.Visible;
            MaskedPasswordInput.Visibility = Visibility.Collapsed;
        }

        private void PasswordCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            MaskedPasswordInput.Password = PasswordInput.Text;
            PasswordInput.Visibility = Visibility.Collapsed;
            MaskedPasswordInput.Visibility = Visibility.Visible;
        }

        private string _captcha = string.Empty;
        private string _source = "qwertyuiopasdfghjklzxcvbnm"
            + "qwertyuiopasdfghjklzxcvbnm".ToUpper()
            + "1234567890";

        /// <summary>
        /// Обновление капчи
        /// </summary>
        private void RefreshCaptcha()
        {
            _captcha = string.Empty;
            CaptchaCanvas.Children.Clear();

            var random = new Random();

            // Генерация четырех символов
            for (var i = 0; i < 4; i++)
            {
                var letter = new TextBlock();
                letter.Margin = new Thickness(i * 64 + random.Next(32),
                    random.Next(32),
                    0, 0);
                letter.Padding = new Thickness(0);
                letter.FontSize = 32;
                letter.Text = _source[random.Next(_source.Length)].ToString();

                _captcha += letter.Text;

                CaptchaCanvas.Children.Add(letter);
            }

            // Зашумление капчи
            for (var x = 0; x < CaptchaCanvas.Width; x++)
            {
                for (var y = 0; y < CaptchaCanvas.Height; y++)
                {
                    var pixel = new Rectangle();
                    pixel.Margin = new Thickness(x, y, 0, 0);
                    pixel.Fill = new SolidColorBrush(
                        Color.FromArgb(
                            (byte)random.Next(128),
                            (byte)random.Next(256),
                            (byte)random.Next(256),
                            (byte)random.Next(256))
                        );
                    pixel.Width = 1;
                    pixel.Height = 1;

                    CaptchaCanvas.Children.Add(pixel);
                }
            }

            // Добавление перечеркивающих линий
            for (var i = 0; i < 8; i++)
            {
                var line = new Line();
                line.StrokeThickness = 2;
                line.Stroke = new SolidColorBrush(
                    Color.FromArgb(
                        (byte)random.Next(128),
                        (byte)random.Next(256),
                        (byte)random.Next(256),
                        (byte)random.Next(256))
                    );
                line.X1 = random.Next(256);
                line.X2 = random.Next(256);
                line.Y1 = random.Next(64);
                line.Y2 = random.Next(64);

                CaptchaCanvas.Children.Add(line);
            }
        }

        private void RefreshCaptchaButton_Click(object sender, RoutedEventArgs e)
        {
            RefreshCaptcha();
        }

        private int _fails = 0;

        private void AuthorizationButton_Click(object sender, RoutedEventArgs e)
        {
            // Если достигнут лимит ошибок, проверять капчу
            if (_fails > 1)
            {
                if (CaptchaInput.Text == _captcha)
                {
                    _fails = 0;
                    CaptchaContainer.Visibility = Visibility.Collapsed;
                }
                else
                {
                    MessageBox.Show("Капча введена неверно!\n" +
                        "Система будет заблокирована на 10 секунд",
                        "Ошибка",
                        MessageBoxButton.OK,
                        MessageBoxImage.Error);
                    Thread.Sleep(10000);
                    MessageBox.Show("Система разблокирована",
                        "Уведомление",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                    return;
                }
            }

            string login = LoginInput.Text;
            string password;

            if (PasswordCheckBox.IsChecked == true)
            {
                password = PasswordInput.Text;
            }
            else
            {
                password = MaskedPasswordInput.Password;
            }

            var user = _entities.User.FirstOrDefault(x => x.Login == login);
            if (user != null)
            {
                user.LastEnter = DateTime.Now;
                _entities.SaveChanges();
            }

            if (user.Password != password)
            {
                user.IsEnterSuccessfull = false;
                _entities.SaveChanges();

                _fails++;

                // Если достигнут лимит ошибок, показать капчу
                if (_fails > 1)
                {
                    RefreshCaptcha();
                    CaptchaContainer.Visibility = Visibility.Visible;
                }

                MessageBox.Show("Неправильный логин или пароль",
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);

                return;
            }

            user.IsEnterSuccessfull = true;
            _entities.SaveChanges();

            switch (user.UserTypeId)
            {
                case 1:
                    // Если входит лаборант и последняя сессия была разорвана системой,
                    // надо проверить, прошел ли срок блокировки
                    if (user.LastSystemLogout != null)
                    {
                        if (DateTime.Now.Ticks - user.LastSystemLogout.Value.Ticks
                            < TimeSpan.FromMinutes(1).Ticks)
                        {
                            MessageBox.Show("Вход заблокирован",
                                "Ошибка",
                                MessageBoxButton.OK,
                                MessageBoxImage.Error);
                            return;
                        }
                    }

                    var assistantWindow = new AssistantWindow(user.Id);
                    assistantWindow.Show();
                    this.Close();
                    break;
                case 2:
                    var bookerWindow = new BookerWindow(user.Id);
                    bookerWindow.Show();
                    this.Close();
                    break;
                case 3:
                    var administratorWindow = new AdministratorWindow(user.Id);
                    administratorWindow.Show();
                    this.Close();
                    break;
            }
        }
    }
}
